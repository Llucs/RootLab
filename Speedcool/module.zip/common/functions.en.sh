#!/system/bin/sh

# SpeedCool v2.1 - Common Functions (common/functions.sh)
# Auxiliary functions common to various module scripts
#
# Author: Llucs

# --- Variables ---
MODDIR="/data/adb/modules/speedcool"
CONFIG_DIR="$MODDIR/configs"
LOG_FILE="$CONFIG_DIR/speedcool.log"

# Ensures the configuration directory exists
mkdir -p "$CONFIG_DIR" || echo "ERROR: Could not create configuration directory: $CONFIG_DIR." >&2

# --- Functions ---

# Function to log events
log() {
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] $1" >> "$LOG_FILE"
    # If DEBUG=1, also display in terminal
    if [ "$DEBUG" = "1" ]; then
        echo "[$timestamp] $1" >&2
    fi
}

# Function to send push notifications
notify_user() {
    local title="SpeedCool"
    local message="$1"
    log "NOTIFICATION: $message"

    # Tries notification via Termux (requires Termux:API)
    if command -v termux-notification >/dev/null 2>&1; then
        termux-notification --title "$title" --content "$message"
    fi

    # Fallback to toast (requires am)
    if command -v am >/dev/null 2>&1; then
        am start -a android.intent.action.VIEW -d "speedcool://notification?title=$title&message=$message" >/dev/null 2>&1
    fi

    # Fallback to echo in logcat (visible via adb logcat)
    echo "SpeedCool: $message" > /dev/kmsg
}

# Function to attempt an operation with retries
retry_command() {
    local cmd="$1"
    local retries=${2:-3} # Default 3 retries
    local delay=${3:-1}  # Default 1 second delay
    local i=0
    while [ $i -lt $retries ]; do
        if eval "$cmd"; then
            return 0
        fi
        i=$((i+1))
        sleep $delay
    done
    log "ERROR: Failed after $retries attempts: $cmd"
    notify_user "Critical failure: $cmd"
    return 1
}

# Function for chipset detection
get_chipset() {
    local platform=$(getprop ro.board.platform)
    local hardware=$(getprop ro.hardware)
    local cpu_abi=$(getprop ro.product.cpu.abi)
    local cpuinfo=$(cat /proc/cpuinfo 2>/dev/null)

    # Tries detection by ro.board.platform
    case "$platform" in
        "msm"*|"sdm"*|"sm"*)
            echo "Qualcomm"
            return
            ;;
        "mt"*)
            echo "MediaTek"
            return
            ;;
        "exynos"*)
            echo "Exynos"
            return
            ;;
        "kirin"*)
            echo "Kirin"
            return
            ;;
        "tensor"*)
            echo "Tensor"
            return
            ;;
    esac

    # Tries detection by ro.hardware
    case "$hardware" in
        "qcom"*)
            echo "Qualcomm"
            return
            ;;
        "mtk"*)
            echo "MediaTek"
            return
            ;;
        "samsung"*)
            echo "Exynos"
            return
            ;;
        "hi"*)
            echo "Kirin"
            return
            ;;
        "google"*)
            echo "Tensor"
            return
            ;;
    esac

    # Tries detection by /proc/cpuinfo
    if echo "$cpuinfo" | grep -qi "qualcomm\|snapdragon"; then
        echo "Qualcomm"
        return
    elif echo "$cpuinfo" | grep -qi "mediatek\|mt6"; then
        echo "MediaTek"
        return
    elif echo "$cpuinfo" | grep -qi "exynos"; then
        echo "Exynos"
        return
    elif echo "$cpuinfo" | grep -qi "kirin\|hisilicon"; then
        echo "Kirin"
        return
    elif echo "$cpuinfo" | grep -qi "google\|tensor"; then
        echo "Tensor"
        return
    elif echo "$cpuinfo" | grep -qi "arm"; then
        echo "ARM_Generic"
        return
    fi

    # Fallback to ABI or unknown
    case "$cpu_abi" in
        *"arm64-v8a"*)
            echo "ARM_Generic"
            ;;
        *)
            echo "Unknown"
            ;;
    esac
}

# Function to load user configurations
load_user_config() {
    local user_config_file="/data/adb/modules/speedcool/user_config.prop"
    if [ -f "$user_config_file" ]; then
        while IFS=\= read -r key value; do
            if [ -n "$key" ]; then
                case "$key" in
                    \#*) ;; # Ignore commented lines
                    *)
                        key=$(echo "$key" | tr -d \"\ )
                        value=$(echo "$value" | tr -d \"\ )
                        export "$key=$value"
                        log "User configuration loaded: $key=$value"
                        ;;
                esac
            fi
        done < "$user_config_file"
    else
        log "Warning: user_config.prop not found. Using default settings."
    fi
}

# Function to check for available governors and schedulers
check_kernel_features() {
    log "Checking available governors and schedulers..."
    local available_governors=""
    local available_schedulers=""

    # Governors
    if [ -d "/sys/devices/system/cpu/cpu0/cpufreq" ]; then
        available_governors=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null)
    fi
    log "Available governors: $available_governors"

    # Schedulers
    for block_device in /sys/block/*; do
        if [ -f "$block_device/queue/scheduler" ]; then
            local schedulers=$(cat "$block_device/queue/scheduler" 2>/dev/null)
            available_schedulers="$available_schedulers $schedulers"
        fi
    done
    log "Available schedulers: $available_schedulers"

    # Check schedutil
    if echo "$available_governors" | grep -q "schedutil"; then
        log "Schedutil governor available."
    else
        log "Schedutil governor NOT available. Using performance as fallback."
        SCHEDUTIL_FALLBACK="performance"
    fi

    # Check performance
    if echo "$available_governors" | grep -q "performance"; then
        log "Performance governor available."
    else
        log "Performance governor NOT available."
        PERFORMANCE_FALLBACK="schedutil" # Fallback for performance
    fi

    # Check powersave
    if echo "$available_governors" | grep -q "powersave"; then
        log "Powersave governor available."
    else
        log "Powersave governor NOT available."
        POWERSAVE_FALLBACK="schedutil" # Fallback for powersave
    fi

    # Check bfq
    if echo "$available_schedulers" | grep -q "bfq"; then
        log "Bfq scheduler available."
    else
        log "Bfq scheduler NOT available. Using noop as fallback."
        BFQ_FALLBACK="noop"
    fi

    # Check kyber
    if echo "$available_schedulers" | grep -q "kyber"; then
        log "Kyber scheduler available."
    else
        log "Kyber scheduler NOT available. Using deadline as fallback."
        KYBER_FALLBACK="deadline"
    fi
}


