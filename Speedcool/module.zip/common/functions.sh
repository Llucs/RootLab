#!/system/bin/sh

# SpeedCool v2.1 - Funções Comuns (common/functions.sh)
# Funções auxiliares comuns a vários scripts do módulo
#
# Autor: Llucs

# --- Variáveis ---
MODDIR="/data/adb/modules/speedcool"
CONFIG_DIR="$MODDIR/configs"
LOG_FILE="$CONFIG_DIR/speedcool.log"

# Garante que o diretório de configuração exista
mkdir -p "$CONFIG_DIR" || echo "ERRO: Não foi possível criar o diretório de configuração: $CONFIG_DIR." >&2

# --- Funções ---

# Função para registrar eventos no log
log() {
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] $1" >> "$LOG_FILE"
    # Se DEBUG=1, também exibe no terminal
    if [ "$DEBUG" = "1" ]; then
        echo "[$timestamp] $1" >&2
    fi
}

# Função para enviar notificações push
notify_user() {
    local title="SpeedCool"
    local message="$1"
    log "NOTIFICAÇÃO: $message"

    # Tenta notificação via Magisk (se houver um método)
    # Magisk não tem uma função nativa de notificação push para módulos diretamente.
    # Isso geralmente é feito por um app complementar ou um script que interage com o Android API.
    # Placeholder para futura integração com um método Magisk-specifico se disponível.
    # if command -v magisk_send_notification >/dev/null 2>&1; then
    #     magisk_send_notification "$title" "$message"
    # fi

    # Tenta notificação via Termux (requer Termux:API)
    if command -v termux-notification >/dev/null 2>&1; then
        termux-notification --title "$title" --content "$message"
    fi

    # Fallback para toast (requer am)
    if command -v am >/dev/null 2>&1; then
        am start -a android.intent.action.VIEW -d "speedcool://notification?title=$title&message=$message" >/dev/null 2>&1
        # am broadcast -a android.intent.action.VIEW -n com.android.shell/.BugreportReceiver --es title "$title" --es text "$message"
    fi

    # Fallback para echo no logcat (visível via adb logcat)
    echo "SpeedCool: $message" > /dev/kmsg
}

# Função para tentar uma operação com retries
retry_command() {
    local cmd="$1"
    local retries=${2:-3} # Padrão de 3 retries
    local delay=${3:-1}  # Padrão de 1 segundo de delay
    local i=0
    while [ $i -lt $retries ]; do
        if eval "$cmd"; then
            return 0
        fi
        i=$((i+1))
        sleep $delay
    done
    log "ERRO: Falha após $retries tentativas: $cmd"
    notify_user "Falha crítica: $cmd"
    return 1
}

# Função para detecção de chipset
get_chipset() {
    local platform=$(getprop ro.board.platform)
    local hardware=$(getprop ro.hardware)
    local cpu_abi=$(getprop ro.product.cpu.abi)
    local cpuinfo=$(cat /proc/cpuinfo 2>/dev/null)

    # Tenta detecção por ro.board.platform
    case "$platform" in
        "msm"*|"sdm"*|"sm"*)
            echo "Qualcomm"
            return
            ;;
        "mt"*)
            echo "MediaTek"
            return
            ;;
        "exynos"*)
            echo "Exynos"
            return
            ;;
        "kirin"*)
            echo "Kirin"
            return
            ;;
        "tensor"*)
            echo "Tensor"
            return
            ;;
    esac

    # Tenta detecção por ro.hardware
    case "$hardware" in
        "qcom"*)
            echo "Qualcomm"
            return
            ;;
        "mtk"*)
            echo "MediaTek"
            return
            ;;
        "samsung"*)
            echo "Exynos"
            return
            ;;
        "hi"*)
            echo "Kirin"
            return
            ;;
        "google"*)
            echo "Tensor"
            return
            ;;
    esac

    # Tenta detecção por /proc/cpuinfo
    if echo "$cpuinfo" | grep -qi "qualcomm\|snapdragon"; then
        echo "Qualcomm"
        return
    elif echo "$cpuinfo" | grep -qi "mediatek\|mt6"; then
        echo "MediaTek"
        return
    elif echo "$cpuinfo" | grep -qi "exynos"; then
        echo "Exynos"
        return
    elif echo "$cpuinfo" | grep -qi "kirin\|hisilicon"; then
        echo "Kirin"
        return
    elif echo "$cpuinfo" | grep -qi "google\|tensor"; then
        echo "Tensor"
        return
    elif echo "$cpuinfo" | grep -qi "arm"; then
        echo "ARM_Generic"
        return
    fi

    # Fallback para ABI ou desconhecido
    case "$cpu_abi" in
        *"arm64-v8a"*)
            echo "ARM_Generic"
            ;;
        *)
            echo "Unknown"
            ;;
    esac
}

# Função para carregar configurações do usuário
load_user_config() {
    local user_config_file="/data/adb/modules/speedcool/user_config.prop"
    if [ -f "$user_config_file" ]; then
        while IFS=\= read -r key value; do
            if [ -n "$key" ]; then
                case "$key" in
                    \#*) ;; # Ignora linhas comentadas
                    *)
                        key=$(echo "$key" | tr -d \"\ )
                        value=$(echo "$value" | tr -d \"\ )
                        export "$key=$value"
                        log "Configuração do usuário carregada: $key=$value"
                        ;;
                esac
            fi
        done < "$user_config_file"
    else
        log "Aviso: user_config.prop não encontrado. Usando configurações padrão."
    fi
}

# Função para verificar a disponibilidade de governors e schedulers
check_kernel_features() {
    log "Verificando governors e schedulers disponíveis..."
    local available_governors=""
    local available_schedulers=""

    # Governors
    if [ -d "/sys/devices/system/cpu/cpu0/cpufreq" ]; then
        available_governors=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null)
    fi
    log "Governors disponíveis: $available_governors"

    # Schedulers
    for block_device in /sys/block/*; do
        if [ -f "$block_device/queue/scheduler" ]; then
            local schedulers=$(cat "$block_device/queue/scheduler" 2>/dev/null)
            available_schedulers="$available_schedulers $schedulers"
        fi
    done
    log "Schedulers disponíveis: $available_schedulers"

    # Verificar schedutil
    if echo "$available_governors" | grep -q "schedutil"; then
        log "Governor schedutil disponível."
    else
        log "Governor schedutil NÃO disponível. Usando performance como fallback."
        SCHEDUTIL_FALLBACK="performance"
    fi

    # Verificar performance
    if echo "$available_governors" | grep -q "performance"; then
        log "Governor performance disponível."
    else
        log "Governor performance NÃO disponível."
        PERFORMANCE_FALLBACK="schedutil" # Fallback para performance
    fi

    # Verificar powersave
    if echo "$available_governors" | grep -q "powersave"; then
        log "Governor powersave disponível."
    else
        log "Governor powersave NÃO disponível."
        POWERSAVE_FALLBACK="schedutil" # Fallback para powersave
    fi

    # Verificar bfq
    if echo "$available_schedulers" | grep -q "bfq"; then
        log "Scheduler bfq disponível."
    else
        log "Scheduler bfq NÃO disponível. Usando noop como fallback."
        BFQ_FALLBACK="noop"
    fi

    # Verificar kyber
    if echo "$available_schedulers" | grep -q "kyber"; then
        log "Scheduler kyber disponível."
    else
        log "Scheduler kyber NÃO disponível. Usando deadline como fallback."
        KYBER_FALLBACK="deadline"
    fi
}


