#!/system/bin/sh
# SpeedCool v2.1 - Desinstalação Segura (uninstall.sh)
# Autor: Llucs

. ${0%/*}/../common/functions.sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/configs"
BACKUP_FILE="$CONFIG_DIR/backup/system_config_backup.conf"

log "📦 Iniciando desinstalação do SpeedCool..."

# Etapa 1: Restauração das Configurações Originais
if [ -f "$BACKUP_FILE" ]; then
  log "🔁 Restaurando configurações originais do sistema..."

  while IFS== read -r key value; do
    case "$key" in
      cpu0_governor)
        path="/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
        [ -w "$path" ] && echo "$value" > "$path" && log "✓ CPU0 governor restaurado: $value"
        ;;
      mmcblk0_scheduler)
        path="/sys/block/mmcblk0/queue/scheduler"
        [ -w "$path" ] && echo "$value" > "$path" && log "✓ Scheduler mmcblk0 restaurado: $value"
        ;;
      *) log "ℹ️ Ignorado: chave desconhecida $key";;
    esac
  done < "$BACKUP_FILE"

else
  log "⚠️ Nenhum backup encontrado. Aplicando configurações seguras padrão..."

  # Governor: schedutil
  for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -w "$gov" ] && echo "schedutil" > "$gov" && log "✓ Governor redefinido (fallback) em $gov"
  done

  # Zonas térmicas
  for therm in /sys/class/thermal/thermal_zone*/mode; do
    [ -w "$therm" ] && echo "enabled" > "$therm" && log "✓ Zona térmica ativada: $therm"
  done
fi

# Etapa 2: Limpeza de arquivos gerados pelo módulo
log "🧹 Removendo arquivos temporários..."

rm -f /data/local/tmp/speedcool_chipset.tmp && log "✓ Removido speedcool_chipset.tmp"
rm -f "$MODDIR/boot_attempt_count" && log "✓ Removido contador de boot"
rm -rf "$MODDIR" && log "✓ Diretório do módulo removido: $MODDIR"

log "✅ SpeedCool removido com sucesso. Sistema restaurado!"
exit 0