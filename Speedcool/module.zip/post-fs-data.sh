#!/system/bin/sh

# SpeedCool v2.1 - post-fs-data.sh
# Executado muito cedo no boot, antes do sistema estar totalmente montado.
#
# Autor: Llucs

# Inclui as funções auxiliares comuns
. ${0%/*}/common/functions.sh

# --- Checagem de Root ---
[ "$(id -u)" -ne 0 ] && {
  log "ERRO: Este script precisa de root para funcionar corretamente." >&2
  exit 1
}

# --- Prevenção de Bootloops (Aprimorada) ---
# A lógica de bootloop foi revisada. Em vez de desativar o módulo, vamos focar em
# garantir que as configurações sejam aplicadas corretamente e que o módulo
# não cause instabilidade. O Magisk já possui mecanismos de segurança para bootloops.
# Remover a lógica de desativação automática para evitar desativações indesejadas.

# Criar diretórios necessários com verificação e log
mkdir -p /data/local/tmp || log "ERRO: Falha ao criar /data/local/tmp"
mkdir -p "$MODDIR/configs" || log "ERRO: Falha ao criar $MODDIR/configs"
mkdir -p "$MODDIR/configs/backup" || log "ERRO: Falha ao criar $MODDIR/configs/backup"

# --- Backup de Configurações Originais do Sistema ---
# Este backup será usado para restaurar as configurações originais na desinstalação.
BACKUP_FILE="$MODDIR/configs/backup/system_config_backup.conf"
if [ ! -f "$BACKUP_FILE" ]; then
    log "Realizando backup das configurações originais do sistema..."
    # Exemplo: Backup do governor atual da CPU0
    if [ -f "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" ]; then
        echo "cpu0_governor=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor)" >> "$BACKUP_FILE"
    fi
    # Exemplo: Backup do scheduler de I/O para mmcblk0
    if [ -f "/sys/block/mmcblk0/queue/scheduler" ]; then
        echo "mmcblk0_scheduler=$(cat /sys/block/mmcblk0/queue/scheduler)" >> "$BACKUP_FILE"
    fi
    # Adicionar mais configurações importantes para backup aqui
    log "Backup das configurações originais concluído em $BACKUP_FILE."
fi

# Detectar chipset e armazenar usando a função unificada
CHIPSET=$(get_chipset)
echo "$CHIPSET" > /data/local/tmp/speedcool_chipset.tmp

# Garantir permissão de execução para todos os scripts (0700) e arquivos de configuração (0600)
for file in config cooling learning_engine menu performance status anti-conflito; do
  [ -f "$MODDIR/scripts/${file}.sh" ] && chmod 0700 "$MODDIR/scripts/${file}.sh"
done

# Permissão para functions.sh
[ -f "$MODDIR/common/functions.sh" ] && chmod 0700 "$MODDIR/common/functions.sh"

# Permissões para arquivos de configuração
chmod 0600 "$MODDIR/settings.conf"
chmod 0600 "$MODDIR/configs/learning_params.conf" 2>/dev/null
chmod 0600 "$MODDIR/configs/conflitos_detectados.conf" 2>/dev/null
chmod 0600 "$MODDIR/configs/backup/system_config_backup.conf" 2>/dev/null

exit 0

