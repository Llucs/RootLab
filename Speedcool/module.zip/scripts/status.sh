#!/system/bin/sh
# SpeedCool v2.1 - Relatório de Status do Sistema (status.sh)
# Autor: Llucs

. ${0%/*}/../common/functions.sh

CONFIG_FILE="$MODDIR/configs/learning_params.conf"
CONFLICT_FILE="$MODDIR/configs/conflitos_detectados.conf"

tput_avail=false
command -v tput >/dev/null && tput_avail=true

reset()   { $tput_avail && tput sgr0; }
bold()    { $tput_avail && tput bold; }
blue()    { $tput_avail && tput setaf 4; }
green()   { $tput_avail && tput setaf 2; }
yellow()  { $tput_avail && tput setaf 3; }
red()     { $tput_avail && tput setaf 1; }

print_section() {
  echo
  blue; bold; echo "═══ $1 ══════════════════════════════════════"; reset
}

bytes_to_mb() {
  echo $(( $1 / 1024 / 1024 ))MB
}

show_cpu_info() {
  print_section "CPU"
  cores=$(grep -c ^processor /proc/cpuinfo)
  usage=$(grep "cpu_usage=" "$CONFIG_FILE" | cut -d= -f2)
  echo "Núcleos: $cores"
  echo "Uso da CPU: ${usage:-N/D}%"

  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    idx=$(basename "$cpu" | sed 's/cpu//')
    freq=$(cat "$cpu/cpufreq/scaling_cur_freq" 2>/dev/null || echo "0")
    gov=$(cat "$cpu/cpufreq/scaling_governor" 2>/dev/null || echo "N/D")
    mhz=$((freq / 1000))
    echo " • CPU$idx: ${mhz}MHz ($gov)"
  done
}

show_ram_info() {
  print_section "RAM"
  usage=$(grep "ram_usage_percent=" "$CONFIG_FILE" | cut -d= -f2)
  echo "Uso de RAM: ${usage:-N/D}%"

  mem_total=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
  mem_free=$(awk '/MemFree/ {print $2}' /proc/meminfo)
  mem_avail=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
  swap_total=$(awk '/SwapTotal/ {print $2}' /proc/meminfo)
  swap_used=$(( $(awk '/SwapTotal/ {total=$2} /SwapFree/ {free=$2} END {print total - free}' /proc/meminfo) ))

  echo "Total: $((mem_total/1024))MB | Livre: $((mem_free/1024))MB | Disponível: $((mem_avail/1024))MB"
  echo "Swap/ZRAM: $((swap_total/1024))MB usados: $((swap_used/1024))MB"
}

show_temp_info() {
  print_section "Temperatura"
  temp=$(grep "cpu_temp=" "$CONFIG_FILE" | cut -d= -f2)
  echo "Temperatura média da CPU: ${temp:-N/D}°C"

  for zone in /sys/class/thermal/thermal_zone*/temp; do
    [ ! -f "$zone" ] && continue
    raw=$(cat "$zone" 2>/dev/null)
    deg=$((raw >= 1000 ? raw / 1000 : raw))
    type=$(cat "${zone%/*}/type" 2>/dev/null)
    echo " • $type: ${deg}°C"
  done
}

show_gpu_info() {
  print_section "GPU"
  gov=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null || echo "N/D")
  freq=$(cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null || echo "0")
  mhz=$((freq / 1000000))
  echo "Frequência: ${mhz}MHz | Governor: $gov"
}

show_battery_info() {
  print_section "Bateria"
  level=$(grep "battery_level=" "$CONFIG_FILE" | cut -d= -f2)
  status=$(grep "battery_status=" "$CONFIG_FILE" | cut -d= -f2)
  echo "Nível: ${level:-N/D}%"
  echo "Status: ${status:-N/D}"
}

show_io_info() {
  print_section "I/O"
  r=$(grep "io_read_bytes=" "$CONFIG_FILE" | cut -d= -f2)
  w=$(grep "io_write_bytes=" "$CONFIG_FILE" | cut -d= -f2)
  echo "Leitura: $(bytes_to_mb ${r:-0})"
  echo "Escrita: $(bytes_to_mb ${w:-0})"
}

show_conflicts() {
  print_section "Conflitos"
  found=$(grep "modulos_conflitantes" "$CONFLICT_FILE" 2>/dev/null | cut -d= -f2)
  [ -z "$found" ] && green; echo "✓ Nenhum conflito detectado."; reset || red; echo "⚠️  Módulos conflitantes: $found"; reset
}

show_mode() {
  mode=$(grep "optimization_profile=" "$CONFIG_FILE" | cut -d= -f2)
  print_section "Modo Ativo"
  echo "Perfil de otimização: ${mode:-N/D}"
}

# Execução principal
show_mode
show_cpu_info
show_gpu_info
show_ram_info
show_temp_info
show_io_info
show_battery_info
show_conflicts

log "Relatório status.sh exibido com sucesso"
exit 0