#!/system/bin/sh

# SpeedCool v2.1 - Gerenciador de Configurações (config.sh)
# Manipula leitura e escrita no learning_params.conf
#
# Autor: Llucs

# --- Variáveis e Caminhos ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_DIR="$SCRIPT_DIR/../configs"
CONFIG_FILE="$CONFIG_DIR/learning_params.conf"

# Inclui funções comuns
. "$SCRIPT_DIR/../common/functions.sh"

# Carrega configurações do usuário
load_user_config

# Sobrescreve DEBUG se definido em user_config.prop
if [ -n "$DEBUG" ]; then
    DEBUG="$DEBUG"
fi

# Garante que o arquivo de configuração exista
mkdir -p "$CONFIG_DIR" || log "ERRO: Não foi possível criar o diretório de configuração: $CONFIG_DIR."
touch "$CONFIG_FILE" || log "ERRO: Não foi possível criar o arquivo de configuração: $CONFIG_FILE."

# --- Funções ---

# Função para obter um valor
# Uso: config.sh get <chave>
get_value() {
    local key="$1"
    if [ -f "$CONFIG_FILE" ]; then
        grep "^${key}=" "$CONFIG_FILE" | cut -d'=' -f2-
    fi
}

# Função para definir um valor
# Uso: config.sh set <chave> <valor>
set_value() {
    local key="$1"
    local value="$2"
    local temp_file="${CONFIG_FILE}.tmp"

    # Cria o arquivo se não existir
    touch "$CONFIG_FILE"

    # Remove a chave antiga (se existir) e adiciona a nova
    grep -v "^${key}=" "$CONFIG_FILE" > "$temp_file"
    echo "${key}=${value}" >> "$temp_file"

    # Substitui o arquivo original pelo temporário
    mv "$temp_file" "$CONFIG_FILE"
    chmod 644 "$CONFIG_FILE"
    log "Configuração atualizada: $key=$value"
}

# --- Lógica Principal ---
COMMAND="$1"
KEY="$2"
VALUE="$3"

case "$COMMAND" in
    get)
        get_value "$KEY"
        ;;
    set)
        if [ -z "$KEY" ] || [ -z "$VALUE" ]; then
            log "ERRO: Uso: config.sh set <chave> <valor>"
            echo "Erro: Uso: config.sh set <chave> <valor>" >&2
            exit 1
        fi
        set_value "$KEY" "$VALUE"
        ;;
    *)
        log "ERRO: Comando inválido. Uso: config.sh [get|set] <chave> [<valor>]"
        echo "Erro: Comando inválido. Uso: config.sh [get|set] <chave> [<valor>]" >&2
        exit 1
        ;;
esac

exit 0