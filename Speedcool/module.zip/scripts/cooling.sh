#!/system/bin/sh
# SpeedCool v2.1 - Gerenciador de Resfriamento Inteligente (cooling.sh)
# Autor: Llucs

. ${0%/*}/../common/functions.sh

load_user_config
[ -n "$DEBUG" ] && DEBUG="$DEBUG"

SENSORS=(
  "/sys/class/thermal/thermal_zone0/temp"
  "/sys/class/thermal/thermal_zone1/temp"
  "/sys/class/power_supply/battery/temp"
  "/sys/class/hwmon/hwmon0/temp1_input"
)

THRESHOLD_ECO=${THRESHOLD_ECO:-45000}
THRESHOLD_PERF=${THRESHOLD_PERF:-60000}
THRESHOLD_CRITICAL=${THRESHOLD_CRITICAL:-70000}

CURRENT_MODE="balanced"

get_temperature() {
  local total=0 count=0
  for sensor in "${SENSORS[@]}"; do
    [ -f "$sensor" ] || continue
    local val=$(cat "$sensor" 2>/dev/null)
    if [ -n "$val" ] && [ "$val" -gt 100 ]; then
      # Converte para milicelsius se necessário
      [ "$val" -lt 1000 ] && val=$((val * 1000))
      total=$((total + val))
      count=$((count + 1))
    fi
  done
  [ "$count" -eq 0 ] && echo 0 || echo $((total / count))
}

apply_governor() {
  local gov="$1"
  for path in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -w "$path" ] && retry_command "echo \"$gov\" > \"$path\"" || log "Falha ao aplicar governor $gov em $path"
  done
  log "Governor aplicado: $gov"
}

apply_mode() {
  local mode="$1"
  log "Aplicando modo de resfriamento: $mode"
  case "$mode" in
    eco)
      apply_governor "${POWERSAVE_FALLBACK:-powersave}"
      ;;
    performance)
      apply_governor "${PERFORMANCE_FALLBACK:-performance}"
      ;;
    cooling)
      apply_governor "${POWERSAVE_FALLBACK:-powersave}"
      ;;
    *)
      apply_governor "${SCHEDUTIL_FALLBACK:-schedutil}"
      ;;
  esac
  CURRENT_MODE="$mode"
}

while true; do
  [ -f "/sys/power/state" ] && [ "$(cat /sys/power/state)" = "mem" ] && {
    log "Dispositivo suspenso - cooling.sh aguardando"
    sleep 60
    continue
  }

  TEMP=$(get_temperature)
  log "Temperatura média detectada: $((TEMP / 1000))ºC (atual modo: $CURRENT_MODE)"

  PROFILE=$(grep '^optimization_profile=' "$MODDIR/configs/learning_params.conf" 2>/dev/null | cut -d= -f2)

  if [ "$TEMP" -ge "$THRESHOLD_CRITICAL" ]; then
    [ "$CURRENT_MODE" != "cooling" ] && apply_mode "cooling"
  elif [ "$PROFILE" = "eco" ] && [ "$TEMP" -le "$THRESHOLD_ECO" ]; then
    [ "$CURRENT_MODE" != "performance" ] && apply_mode "performance"
  elif [ "$PROFILE" = "performance" ] && [ "$TEMP" -ge "$THRESHOLD_PERF" ]; then
    [ "$CURRENT_MODE" != "eco" ] && apply_mode "eco"
  else
    [ "$CURRENT_MODE" != "$PROFILE" ] && apply_mode "$PROFILE"
  fi

  sleep 5
done