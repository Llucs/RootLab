#!/system/bin/sh
# SpeedCool v2.1 - Gerenciador de Desempenho (performance.sh)
# Autor: Llucs

. ${0%/*}/../common/functions.sh

CONFIG_SCRIPT="$MODDIR/scripts/config.sh"
LEARNING_CONFIG_FILE="$MODDIR/configs/learning_params.conf"

load_user_config
[ -n "$DEBUG" ] && DEBUG="$DEBUG"

# Obtém parâmetro do Motor de Aprendizado
get_learning_param() {
  local key="$1"
  [ -f "$LEARNING_CONFIG_FILE" ] && grep "^$key=" "$LEARNING_CONFIG_FILE" | cut -d= -f2
}

set_cpu_governor() {
  local gov="$1"
  local cpu_total=$(grep -c ^processor /proc/cpuinfo)

  for cpu in $(seq 0 $((cpu_total - 1))); do
    local gov_path="/sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_governor"
    [ -w "$gov_path" ] && retry_command "echo \"$gov\" > \"$gov_path\"" || log "AVISO: Governor $gov não aplicável em cpu$cpu"
  done
  log "Governor de CPU definido como: $gov"
}

set_cpu_freq_limits() {
  local min="$1"
  local max="$2"
  local cpu_total=$(grep -c ^processor /proc/cpuinfo)
  local chipset=$(get_chipset)

  for cpu in $(seq 0 $((cpu_total - 1))); do
    local base_min=$(cat /sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_min_freq 2>/dev/null)
    local base_max=$(cat /sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_max_freq 2>/dev/null)
    local min_path="/sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_min_freq"
    local max_path="/sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_max_freq"

    case "$chipset" in
      Qualcomm|MediaTek|Exynos)
        retry_command "echo \"$base_min\" > \"$min_path\""
        retry_command "echo \"$base_max\" > \"$max_path\""
        ;;
      *)
        retry_command "echo \"${min:-$base_min}\" > \"$min_path\""
        retry_command "echo \"${max:-$base_max}\" > \"$max_path\""
        ;;
    esac
  done
}

set_io_scheduler() {
  local target="$1"
  local chipset=$(get_chipset)

  for blk in /sys/block/*; do
    local sched_path="$blk/queue/scheduler"
    [ ! -w "$sched_path" ] && continue
    local scheds=$(cat "$sched_path")

    case "$chipset" in
      Qualcomm|MediaTek|Exynos) log "Pulando I/O scheduler para $blk (chipset: $chipset)" ;;
      *)
        if echo "$scheds" | grep -q "$target"; then
          retry_command "echo \"$target\" > \"$sched_path\""
        else
          log "Scheduler $target não disponível em $blk; pulando."
        fi
        ;;
    esac
  done
}

optimize_gpu() {
  local mode="$1"
  local gov_path="/sys/class/kgsl/kgsl-3d0/devfreq/governor"
  local min_freq="/sys/class/kgsl/kgsl-3d0/devfreq/min_freq"
  local max_freq="/sys/class/kgsl/kgsl-3d0/devfreq/max_freq"

  [ ! -w "$gov_path" ] && { log "GPU: caminho governor não disponível"; return; }

  case "$mode" in
    eco)
      retry_command "echo \"powersave\" > \"$gov_path\""
      [ -r "$min_freq" ] && val=$(cat "$min_freq") && retry_command "echo $((val * 80 / 100)) > \"$max_freq\""
      ;;
    performance)
      retry_command "echo \"performance\" > \"$gov_path\""
      ;;
    balanced)
      retry_command "echo \"simple_ondemand\" > \"$gov_path\""
      ;;
  esac
}

optimize_network() {
  local mode="$1"
  local path="/proc/sys/net/ipv4/tcp_congestion_control"

  [ ! -w "$path" ] && { log "tcp_congestion_control indisponível"; return; }

  case "$mode" in
    eco|balanced) retry_command "echo \"cubic\" > \"$path\"" ;;
    performance)  retry_command "echo \"bbr\" > \"$path\"" ;;
  esac
}

apply_profile() {
  local profile="$1"
  log "Aplicando perfil de desempenho: $profile"

  case "$profile" in
    eco)
      set_cpu_governor "${SCHEDUTIL_FALLBACK:-powersave}"
      set_cpu_freq_limits 0 $(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq | awk '{print int($1*0.7)}')
      set_io_scheduler "${BFQ_FALLBACK:-bfq}"
      optimize_gpu "eco"
      optimize_network "eco"
      ;;
    performance)
      set_cpu_governor "${PERFORMANCE_FALLBACK:-performance}"
      set_cpu_freq_limits 0 0
      set_io_scheduler "${KYBER_FALLBACK:-mq-deadline}"
      optimize_gpu "performance"
      optimize_network "performance"
      ;;
    balanced|learning)
      set_cpu_governor "${SCHEDUTIL_FALLBACK:-schedutil}"
      set_cpu_freq_limits 0 0
      set_io_scheduler "${KYBER_FALLBACK:-bfq}"
      optimize_gpu "balanced"
      optimize_network "balanced"
      ;;
    *)
      log "Perfil desconhecido: $profile. Usando fallback balanced."
      apply_profile "balanced"
      ;;
  esac
}

while true; do
  [ -f "/sys/power/state" ] && [ "$(cat /sys/power/state)" = "mem" ] && {
    log "performance.sh suspenso em modo sleep"
    sleep 60
    continue
  }

  local PROFILE="$(get_learning_param "optimization_profile")"

  if [ -z "$PROFILE" ]; then
    local MODE=$($CONFIG_SCRIPT get current_mode)
    apply_profile "${MODE:-balanced}"
  else
    apply_profile "$PROFILE"
  fi

  sleep 10
done