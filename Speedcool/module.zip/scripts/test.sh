#!/system/bin/sh

# SpeedCool v2.1 - Script de Testes (test.sh)
# Este script simula cenários de uso para verificar a estabilidade e o comportamento do módulo SpeedCool.
#
# Autor: Llucs

# --- Variáveis e Caminhos ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_SCRIPT="$SCRIPT_DIR/config.sh"
STATUS_SCRIPT="$SCRIPT_DIR/status.sh"

# Inclui funções comuns
. "$SCRIPT_DIR/../common/functions.sh"

log "Iniciando testes do SpeedCool v2.1..."

# --- Cenário 1: Alta Carga de CPU ---
echo "\n=== Teste de Alta Carga de CPU ==="
log "Simulando alta carga de CPU..."
# Ativa o modo performance
$CONFIG_SCRIPT set current_mode performance

# Simula carga de CPU por 30 segundos
(for i in $(seq 1 $(nproc)); do while :; do :; done & done) & PID_LOAD=$!
sleep 30
kill $PID_LOAD 2>/dev/null
killall : 2>/dev/null

log "Verificando status após alta carga..."
$STATUS_SCRIPT

# --- Cenário 2: Baixa Bateria (Simulação) ---
echo "\n=== Teste de Baixa Bateria ==="
log "Simulando baixa bateria e modo Eco..."
# Ativa o modo eco
$CONFIG_SCRIPT set current_mode eco

# Simula bateria baixa (não altera o hardware real, apenas para lógica interna)
# Não há um caminho direto para simular isso via shell para o módulo reagir.
# A lógica de baixa bateria é tratada pelo learning_engine.sh com base no `battery_level`.
# Para um teste real, seria necessário um dispositivo com bateria baixa.

log "Verificando status após simulação de baixa bateria..."
$STATUS_SCRIPT

# --- Cenário 3: Alternância de Modos ---
echo "\n=== Teste de Alternância de Modos ==="
log "Alternando entre modos Eco e Performance..."

$CONFIG_SCRIPT set current_mode eco
log "Modo atual: Eco"
sleep 10

$CONFIG_SCRIPT set current_mode performance
log "Modo atual: Performance"
sleep 10

$CONFIG_SCRIPT set current_mode learning
log "Modo atual: Aprendizado"
sleep 10

log "Verificando status após alternância de modos..."
$STATUS_SCRIPT

# --- Cenário 4: Verificação de Conflitos (Simulação) ---
echo "\n=== Teste de Verificação de Conflitos ==="
log "Simulando detecção de conflitos..."
# Cria um arquivo de conflito simulado
mkdir -p "$SCRIPT_DIR/../configs"
echo "modulos_conflitantes=modulo_conflitante_simulado" > "$SCRIPT_DIR/../configs/conflitos_detectados.conf"

# Força o learning_engine a reavaliar (em um ambiente real, ele faria isso periodicamente)
killall -HUP learning_engine.sh 2>/dev/null
sleep 5

log "Verificando status após simulação de conflito..."
$STATUS_SCRIPT

# Limpa o conflito simulado
rm -f "$SCRIPT_DIR/../configs/conflitos_detectados.conf"

log "Testes do SpeedCool v2.1 concluídos. Verifique o log para detalhes."

exit 0


