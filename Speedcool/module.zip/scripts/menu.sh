#!/system/bin/sh
# SpeedCool v2.1 - Menu Interativo com Cores (menu.sh)
# Autor: Llucs

. ${0%/*}/../common/functions.sh

CONFIG_SCRIPT="$MODDIR/scripts/config.sh"
STATUS_SCRIPT="$MODDIR/scripts/status.sh"
CONFIG_FILE="$MODDIR/configs/learning_params.conf"
CONFLICT_FILE="$MODDIR/configs/conflitos_detectados.conf"

mkdir -p "$MODDIR/configs"
touch "$CONFIG_FILE" "$CONFLICT_FILE"

# Verifica se tput está disponível (para Termux colorido)
tput_available=false
command -v tput >/dev/null && tput_available=true

# Estilos
reset_color()   { $tput_available && tput sgr0; }
bold()          { $tput_available && tput bold; }
blue()          { $tput_available && tput setaf 4; }
green()         { $tput_available && tput setaf 2; }
yellow()        { $tput_available && tput setaf 3; }
red()           { $tput_available && tput setaf 1; }

pause() {
  printf "\n"; read -r -p "Pressione Enter para continuar..."
}

header() {
  clear
  blue; bold
  echo "╔══════════════════════════════════════════════════╗"
  echo "║         SpeedCool Menu Interativo v2.1           ║"
  echo "╚══════════════════════════════════════════════════╝"
  reset_color
}

show_current_mode() {
  MODE=$($CONFIG_SCRIPT get current_mode)
  [ -z "$MODE" ] && MODE="Nenhum (Padrão)"
  yellow; echo "Modo atual: $MODE"; reset_color
}

select_mode() {
  while true; do
    header; show_current_mode
    echo ""
    echo " [1] Eco         → Economia e resfriamento leve"
    echo " [2] Desempenho → Máxima performance"
    echo " [3] Aprendizado → Otimização adaptativa"
    echo " [0] Voltar"
    printf "\nEscolha uma opção: "; read -r choice
    case "$choice" in
      1) $CONFIG_SCRIPT set current_mode eco         && green; echo "✓ Modo Eco ativado"; reset_color; break ;;
      2) $CONFIG_SCRIPT set current_mode performance && green; echo "✓ Modo Desempenho ativado"; reset_color; break ;;
      3) $CONFIG_SCRIPT set current_mode learning    && green; echo "✓ Modo Aprendizado ativado"; reset_color; break ;;
      0) break ;;
      *) red; echo "Opção inválida!"; reset_color ;;
    esac
    pause
  done
}

show_status() {
  header
  echo -e "\nEstado Atual do Sistema:\n"
  $STATUS_SCRIPT
  pause
}

manage_conflicts() {
  header
  echo -e "\nGerenciador de Conflitos:\n"
  CONFLITOS=$(grep "modulos_conflitantes" "$CONFLICT_FILE" 2>/dev/null | cut -d= -f2)
  if [ -n "$CONFLITOS" ]; then
    red; echo "⚠️  Módulos conflitantes detectados: $CONFLITOS"; reset_color
    echo ""
    echo " [1] Desativar módulos conflitantes (requer reinício)"
    echo " [0] Voltar"
    printf "\nEscolha: "; read -r option
    if [ "$option" = "1" ]; then
      read -r -p "Tem certeza que deseja desativá-los? (s/N): " confirm
      if echo "$confirm" | grep -qi "^s"; then
        for module in $CONFLITOS; do
          for base in /data/adb/modules /data/adb/ksu/modules; do
            [ -d "$base/$module" ] && touch "$base/$module/disable" && green; echo "✓ $module desativado"; reset_color
          done
        done
        green; echo "✓ Conflitos resolvidos. Reinicie o dispositivo."; reset_color
      else
        yellow; echo "Operação cancelada pelo usuário."; reset_color
      fi
    fi
  else
    green; echo "Nenhum conflito detectado!"; reset_color
  fi
  pause
}

export_logs() {
  header
  LOG_SOURCE="$MODDIR/configs/speedcool.log"
  EXPORT_DIR="/sdcard/SpeedCool_logs"
  mkdir -p "$EXPORT_DIR"
  TARGET="$EXPORT_DIR/log_$(date +%Y%m%d_%H%M%S).log"

  if [ -f "$LOG_SOURCE" ]; then
    cp "$LOG_SOURCE" "$TARGET" && green; echo "✓ Log exportado para $TARGET"; reset_color
  else
    red; echo "Arquivo de log não encontrado em $LOG_SOURCE"; reset_color
  fi
  pause
}

check_updates() {
  header
  echo -e "\nVerificando atualizações...\n"
  local current=$(grep "^version=" "$MODDIR/module.prop" | cut -d= -f2)
  local latest=$(curl -s https://raw.githubusercontent.com/Llucs/SpeedCool-Magisk-Module/main/module.prop | grep "^version=" | cut -d= -f2)

  if [ -z "$latest" ]; then
    red; echo "Erro: não foi possível verificar a versão mais recente (sem conexão?)"; reset_color
  elif [ "$current" = "$latest" ]; then
    green; echo "✔ Você está usando a versão mais recente: $current"; reset_color
  else
    yellow; echo "⚠️ Nova versão disponível: $latest (sua: $current)"; reset_color
    echo "🔗 Baixe em: https://github.com/Llucs/SpeedCool-Magisk-Module"
  fi
  pause
}

# Menu principal
while true; do
  header
  show_current_mode
  echo ""
  echo " [1] Alterar Modo (Eco / Desempenho / Aprendizado)"
  echo " [2] Ver Status do Sistema"
  echo " [3] Gerenciar Conflitos"
  echo " [4] Exportar Logs"
  echo " [5] Verificar Atualizações"
  echo " [0] Sair"
  printf "\nEscolha uma opção: "; read -r option
  case "$option" in
    1) select_mode ;;
    2) show_status ;;
    3) manage_conflicts ;;
    4) export_logs ;;
    5) check_updates ;;
    0) echo -e "\nVolte sempre ✨"; exit 0 ;;
    *) red; echo "Opção inválida!"; reset_color; pause ;;
  esac
done

