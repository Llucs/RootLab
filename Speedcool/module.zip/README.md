# ⚡ SpeedCool v2.1 - Módulo Magisk Supremo ❄️🔥

**Autor:** Llucs  
**Versão:** 2.1

> 🔥 Potência máxima com controle térmico avançado – agora mais inteligente, bonito e seguro do que nunca!

---

## 🚀 Visão Geral

O **SpeedCool** é um módulo Magisk avançado que otimiza o desempenho e a eficiência energética do Android. Atua dinamicamente na CPU, I/O, RAM e temperatura, com inteligência adaptativa para garantir fluidez, economia de bateria e resfriamento eficaz.

---

## ✨ Funcionalidades Principais

* **🔍 Otimização Inteligente:** Motor adaptativo que aprende com seu uso e ajusta os parâmetros automaticamente.
* **🎮 Modos de Desempenho:** Perfis Eco, Performance e Balanceado, além de um modo Aprendizado.
* **📈 Gerenciamento de CPU e I/O:** Governors e schedulers otimizados conforme o perfil.
* **🧊 Super Resfriamento Inteligente:** Detecta superaquecimento e responde com ajustes dinâmicos.
* **🧠 Gerenciamento de RAM:** Libera memória automaticamente, mantendo o sistema ágil.
* **🖥️ Menu Interativo:** Acesso via Termux com visual colorido, moderno e intuitivo.
* **🌐 Internacionalização:** Suporte completo a português e inglês.
* **⚙️ Configuração Avançada:** Arquivo `settings.conf` personalizável para ajustes profundos.

---

## 📱 Compatibilidade

Compatível com a maioria dos dispositivos Android rooteados com Magisk.
- **Arquiteturas suportadas:** Qualcomm, MediaTek, Exynos
- Detecta automaticamente o chipset e aplica otimizações específicas.

---

## 🧠 Governors e Schedulers Utilizados

### Governors de CPU:
- `schedutil` – Padrão (Eco/Balanceado)
- `performance` – Alta performance (jogos/tarefas pesadas)
- `powersave` – Economia de energia (modo Cooling)
- `interactive` – Resposta rápida à carga

### Schedulers de I/O:
- `bfq` – Suave para apps interativos (Eco/Balanceado)
- `mq-deadline` – Baixa latência (modo Performance)
- `kyber` – Otimizado para armazenamento rápido
- `cfq` – Compatibilidade com kernels antigos

---

## 🛡️ Melhorias na v2.1

* Aprendizado adaptativo baseado em uso real e horário.
* Perfis com comportamento noturno automático (Eco após 1h).
* Interface colorida otimizada para Termux.
* Status em tempo real de CPU, RAM, GPU, Bateria e I/O.
* Compatibilidade com sensores limitados.
* Inicialização e desinstalação seguras.
* Detecção refinada de conflitos com outros módulos ou governors.

---

## 🗑️ Como Remover o Módulo

### ✅ Via Magisk Manager:
- Acesse `Magisk > Módulos`
- Toque no ícone de lixeira ao lado de "SpeedCool"
- Reinicie o dispositivo

### 💡 Via Recovery:
- Navegue até `/data/adb/modules`
- Exclua a pasta `speedcool`
- Reinicie o sistema

### 🚨 Bootloop:
- Acesse via TWRP ou OrangeFox com OTG/pendrive/cartão SD
- Exclua `/data/adb/modules/speedcool`
- Ou use o `Magisk Uninstaller.zip` para remover o Magisk e os módulos

---

## 📚 Guia Rápido de Uso

### Para Iniciantes:
1. Instale o arquivo `.zip` via Magisk
2. Reinicie o dispositivo
3. No Termux, digite: `speedcool`
4. Use o menu:
   - `1) Selecionar Modo`
   - `2) Ver Estado do Sistema`

### Para Avançados:
- Edite `/data/adb/modules/speedcool/settings.conf` com root:
 ``bash
# DEFAULT_MODE="Performance"
# ENABLE_LEARNING_ENGINE="true"
# OPTIMIZATION_PROFILE="balanced"


---

📢 Suporte e Comunidade

GitHub: github.com/Llucs/SpeedCool-Magisk-Module

Telegram: t.me/SpeedCool_Releases



---

📥 Download

Baixe a versão mais recente no repositório GitHub oficial:

👉 ⏬ Download SpeedCool v2.1
github.com/Llucs/SpeedCool-Magisk-Module

---

Feito com ❤️ para quem ama performance sem calor.

---




























































































































# c3BlZWRjb29sIGJ5IExsdWNzIDIwMjU=